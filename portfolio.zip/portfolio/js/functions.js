

$(document).ready(function () {	    

    $(".card").flip({
      axis: 'y',  
      trigger: 'hover',
      reverse: false,
      speed: 2000

    });
    
	var msg = getURLVariable("message");	
	if(msg == "send"){
		console.log(msg);
		
    $(".msg").css("display", "block");
  	$(".msg").fadeOut(3000);
  
    setTimeout(function(){
      //location.reload();
      window.location.href = "index.html";
    },5000);

  }
});


// Return the url parameter value return a string
function getURLVariable(variable) {
	var query = window.location.search.substring(1);
	var vars = query.split("&");	
	for (i=0;i<vars.length;i++) {
    	var pair = vars[i].split("=");
	    if (pair[0] == variable) {
    	  return pair[1];
    	}
  	}
}