<?php
	require_once 'vendor/autoload.php';

	
	if(isset($_POST)){
	
		$replyTo = $_POST['email'] ;
		$fromName = $_POST['name'] . ' ' . $_POST['surname'];
		$message= $_POST['message'];
	}
	

	$m = new PHPMailer;

	$m->isSMTP();

	$m->SMTPAuth = true;

	$m->SMTPDebug = 0;

	//$m->Host = 'smtp.gmail.com';
	$m->Host = 'just38.justhost.com';

	//$m->Username = 'wiza3dapp@gmail.com';
	//$m->Password = 'Mygenius18';
	$m->Username = 'portfolio@michiozo.co.uk';
	$m->Password = 'P0rtf0l!0';

	$m->SMTPSecure = 'ssl';
	$m->Port = 465;


	
	if(!empty($replyTo)){
		$m->addReplyTo($replyTo,'Reply Address');		
	}

	if(!empty($fromName)){
		$m->FromName = $fromName;
	}
	
	
	$m->From = 'portfolio@michiozo.co.uk';	

	//$m->addReplyTo('reply@michiozo.co.uk','Reply Address');
	$m->addAddress('ajb.app@gmail.com','Portfolio');

	$m->Subject ='Mail from Portfolio Site';
	$m->Body = $message;
	$m->AltBody = $message;

	if($m->send()){
		echo '<script type="text/javascript">
			location.href = "index.html?message=send#page6"; 			
		</script>';
	}else{
		echo $m->ErrorInfo;
	}
